package com.jesufertez.nocompresarrienda.model

data class Attributes (
    val engine : String="",
    val transmition: String="",
    val entertainment:String="",
    val security: String=""
        )