package com.jesufertez.nocompresarrienda.util

interface OnItemClick {
    fun onItemClick(position: Int,id : String)
}